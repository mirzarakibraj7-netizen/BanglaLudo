BANGLA LUDO — Android + AdMob
Package name: com.mirzaraj.banglaludo
==============================
আপনার AdMob App ID: ca-app-pub-7808329877913294~9456707590

ধাপ (কম্পিউটারে, Node.js + Android Studio লাগবে):
1. এই ফোল্ডারে টার্মিনাল খুলুন
2. bash setup.sh
3. npx cap open android   → Android Studio খুলবে
4. Build > Build Bundle(s)/APK(s) > Build APK(s)

যদি setup.sh Manifest-এ ID না বসাতে পারে, android/app/src/main/AndroidManifest.xml-এ
<application ...> ট্যাগের ভেতরে নিজে বসান:
  <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID"
             android:value="ca-app-pub-7808329877913294~9456707590"/>

বিজ্ঞাপন: www/ads.js-এ TESTING=true (টেস্ট বিজ্ঞাপন, উপরে ছোট স্ট্যাটাস লেখা দেখায়)। আসল বিজ্ঞাপনের জন্য TESTING=false করুন।
AdMob-এ Banner ও Interstitial ইউনিট বানিয়ে BANNER ও INTER-এ আসল ID বসান,
আর TESTING=false করুন। টেস্টের সময় নিজের আসল বিজ্ঞাপনে ক্লিক করবেন না।

কম্পিউটার ছাড়া APK (GitHub দিয়ে):
1. github.com-এ বিনামূল্যে অ্যাকাউন্ট খুলে New repository বানান
2. এই ফোল্ডারের সব ফাইল (.github ফোল্ডারসহ) আপলোড করুন
3. Actions ট্যাব > Build APK > Run workflow
4. ৫-১০ মিনিট পরে শেষ রানে Artifacts থেকে BANGLA-LUDO-apk নামান

নতুন: ১) আইকন android-res ফোল্ডারে (বিল্ডের সময় নিজে বসে)
      ২) রং বেছে নেওয়া (২ জনে) ও র‍্যাঙ্কিং নিয়ম (শেষ একজন বাকি থাকলে খেলা শেষ)
