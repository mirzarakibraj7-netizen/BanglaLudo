/* AdMob সেতু — ব্রাউজারে কিছুই করে না, শুধু Android অ্যাপে চলে */
(function(){
 // TESTING=true হলে Google-এর টেস্ট বিজ্ঞাপন আসবে (সাথে সাথে)। আসল বিজ্ঞাপনের জন্য false করুন।
 var TESTING=true;
 var REAL_BANNER="ca-app-pub-7808329877913294/3479998741";
 var REAL_INTER="ca-app-pub-7808329877913294/7098137565";
 var BANNER=TESTING?"ca-app-pub-3940256099942544/6300978111":REAL_BANNER;
 var INTER=TESTING?"ca-app-pub-3940256099942544/1033173712":REAL_INTER;
 var A=null,ready=false,games=0,box=null;
 function say(t){try{if(!box){box=document.createElement("div");box.style.cssText="position:fixed;left:0;right:0;top:0;z-index:99;font:11px sans-serif;background:#000c;color:#fff;padding:3px 6px;text-align:center;pointer-events:none";document.body.appendChild(box)}box.textContent="AdMob: "+t}catch(e){}}
 function pad(h){try{var v=Math.ceil(h)+20;document.documentElement.style.setProperty("--adh",v+"px");document.body.style.paddingBottom=v+"px"}catch(e){}}
 function plug(){try{return window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform()?Capacitor.Plugins.AdMob:null}catch(e){return null}}
 function on(ev,fn){try{A.addListener(ev,fn)}catch(e){}}
 async function init(){A=plug();
  if(!A){if(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform())say("প্লাগিন পাওয়া যায়নি");return}
  say("শুরু হচ্ছে"+(TESTING?" (টেস্ট মোড)":""));
  on("bannerAdLoaded",function(){say("ব্যানার লোড হয়েছে ✓")});
  on("bannerAdSizeChanged",function(e){if(e&&e.height)pad(e.height)});
  on("bannerAdFailedToLoad",function(e){say("ব্যানার ব্যর্থ: "+(e&&(e.message||e.code))+" ["+(e&&e.code)+"]")});
  on("onAdFailedToLoad",function(e){say("ব্যর্থ: "+(e&&(e.message||e.code)))});
  on("interstitialAdFailedToLoad",function(e){say("ফুলস্ক্রিন ব্যর্থ: "+(e&&(e.message||e.code))+" ["+(e&&e.code)+"]")});
  on("interstitialAdLoaded",function(){say("ফুলস্ক্রিন প্রস্তুত ✓")});
  try{await A.initialize({initializeForTesting:TESTING});ready=true;say("চালু, ব্যানার চাওয়া হচ্ছে…");
   await A.showBanner({adId:BANNER,adSize:"ADAPTIVE_BANNER",position:"BOTTOM_CENTER",margin:0,isTesting:TESTING});
   pad(90);
   A.prepareInterstitial({adId:INTER,isTesting:TESTING}).catch(function(e){say("ফুলস্ক্রিন প্রস্তুতি ব্যর্থ: "+(e&&e.message))});
  }catch(e){say("ত্রুটি: "+(e&&(e.message||e)))}}
 window.LudoAds={
  gameEnd:async function(){if(!ready)return;games++;if(games%2)return;
   try{await A.showInterstitial();A.prepareInterstitial({adId:INTER,isTesting:TESTING}).catch(function(){})}catch(e){say("ফুলস্ক্রিন দেখানো যায়নি: "+(e&&e.message))}}
 };
 document.addEventListener("DOMContentLoaded",init);
})();
