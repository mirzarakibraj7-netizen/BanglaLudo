BANGLA LUDO — Play Store (AAB) প্রজেক্ট
========================================
Package name : com.mirzaraj.banglaludo
AdMob App ID : ca-app-pub-7808329877913294~9456707590
এই ভার্সন Capacitor 8 (Android target API 36) — Play Store-এর বর্তমান নিয়ম অনুযায়ী।

⚠️ আগে করুন: GitHub repository-টি PRIVATE করুন (Settings > General > Danger Zone > Change visibility)।
   কারণ প্রথম বিল্ডে সাইনিং-চাবি বানিয়ে Artifacts-এ দেওয়া হয়; public repo-তে অন্যরা নামাতে পারে।

ধাপ:
1. নতুন একটা repository বানান (অথবা আগেরটায় পুরনো সব zip মুছুন)
2. BANGLA-LUDO-Play.zip আপলোড করুন (খুলতে হবে না) + .github/workflows/build-aab.yml ফাইলটা repository-তে বসান
3. Actions > "Build AAB (Play Store)" > Run workflow
4. শেষে Artifacts থেকে নামান:
   - BANGLA-LUDO-aab-runN  → Play Console-এ আপলোডের ফাইল (BANGLA-LUDO.aab)
   - SAVE-THIS-KEYSTORE   → চাবি (upload.jks + KEYSTORE-INFO.txt) — নিরাপদ জায়গায় রাখুন, অন্য কাউকে দেবেন না
5. পরের আপডেটে একই চাবি লাগবে: KEYSTORE-INFO.txt দেখে GitHub Secrets-এ বসান:
   KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS (= bangla)

Play Console-এ (play.google.com/console, ২৫ ডলার এককালীন ফি):
 - Create app > Production (বা Internal testing আগে) > .aab আপলোড
 - "Play App Signing" চালু রাখুন (ডিফল্ট)
 - Privacy policy URL: PRIVACY-POLICY.html ফাইলটা GitHub Pages-এ রেখে লিংক দিন (আগে ইমেইল বসান)
 - Data safety ফর্মে: বিজ্ঞাপনের জন্য Advertising ID ব্যবহার হয় — হ্যাঁ বলুন
 - Ads declaration: "Contains ads" — হ্যাঁ
 - AdMob-এ অ্যাপটা Play Store অ্যাপের সাথে যুক্ত (link) করুন
