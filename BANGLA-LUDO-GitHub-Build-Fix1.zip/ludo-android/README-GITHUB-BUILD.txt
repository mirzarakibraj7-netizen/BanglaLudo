BANGLA LUDO — GitHub Cloud Build (Android APK)

This project is prepared for GitHub Actions. It does NOT contain a compiled APK yet.

PHONE-ONLY STEPS
1. Extract this ZIP on your phone (Files app / ZArchiver).
2. Open GitHub in Chrome and create a NEW repository named Bangla-Ludo.
3. In the repository, upload the CONTENTS of the ludo-android folder to the repository root.
   IMPORTANT: include the hidden .github/workflows/build-android.yml file/folder.
   If GitHub mobile upload hides .github, use GitHub's web interface in Chrome Desktop site mode,
   or create the workflow file manually at .github/workflows/build-android.yml.
4. Open the repository's Actions tab.
5. Select “Build Bangla Ludo APK” and press “Run workflow”.
6. Wait for the workflow to finish with a green check.
7. Open the successful workflow run, scroll to Artifacts, and download
   “Bangla-Ludo-debug-APK”. Extract the downloaded artifact ZIP; inside is app-debug.apk.

BUILD NOTES
- Package: com.mirzaraj.banglaludo
- Capacitor 6 / Java 17 / Android Gradle build.
- Output is a DEBUG APK for testing and sideloading, not a Play Store release.
- Check AdMob setup and test ads on a test device. Never click your own live ads.
- The workflow configures the AdMob App ID found in setup.sh.
- www/ads.js currently contains the ad unit IDs from the supplied project. Verify these IDs
  in your own AdMob account before publishing. Do not expose private signing keys or passwords.
